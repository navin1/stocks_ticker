# utils/sql_loader.py
#
# Loads SQL from .sql files and optionally injects runtime params.
# Each DAG passes its own absolute SQL path — no hardcoding needed.

from pathlib import Path


def load_sql(sql_path: str | Path, sql_params: dict = None) -> str:
    """
    Reads a .sql file and optionally formats it with runtime params.

    Args:
        sql_path   : Absolute path to the .sql file (str or Path)
        sql_params : Optional dict of params to inject via str.format()
                     e.g. {"dag_id": "dag_finance_1", "run_id": "{{ run_id }}"}

    Returns:
        SQL string ready to pass to BigQueryInsertJobOperator

    Raises:
        FileNotFoundError if the .sql file does not exist

    Example:
        load_sql(SQL_BASE / "validate_sales.sql",
                 sql_params={"dag_id": "dag_finance_1", "run_id": "{{ run_id }}"})
    """
    path = Path(sql_path)

    if not path.exists():
        raise FileNotFoundError(
            f"[SQLLoader] SQL file not found: {path}\n"
            f"Check that the file exists and the path is correct."
        )

    sql = path.read_text(encoding="utf-8").strip()

    if sql_params:
        try:
            sql = sql.format(**sql_params)
        except KeyError as e:
            raise KeyError(
                f"[SQLLoader] Missing sql_param key {e} for file: {path}"
            )

    return sql
