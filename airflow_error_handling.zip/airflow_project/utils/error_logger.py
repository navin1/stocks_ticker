# utils/error_logger.py
#
# Centralized error logger — reused across ALL DAGs.
# Inserts structured error rows into BQ dag_error_log table.

from google.cloud import bigquery
from datetime import datetime
import traceback

BQ_CLIENT   = bigquery.Client()
ERROR_TABLE = "your_project.your_dataset.dag_error_log"  # ← update this


def on_task_failure(context: dict):
    """
    Attach this as on_failure_callback to any BigQueryInsertJobOperator.
    Captures dag_id, task_id, dag_run_id, table_name, error details.

    Automatically called by Airflow on task failure.
    """
    ti        = context.get("task_instance")
    exception = context.get("exception")

    table_name = _extract_table_name(ti)

    row = [{
        "dag_id":        context["dag"].dag_id,
        "task_id":       ti.task_id,
        "dag_run_id":    context.get("run_id", "unknown"),
        "run_timestamp": datetime.utcnow().isoformat(),
        "error_type":    type(exception).__name__ if exception else "AirflowException",
        "error_message": str(exception) if exception else "Unknown error",
        "traceback":     traceback.format_exc(),
        "table_name":    table_name,
        "record_json":   None,   # N/A for SQL job-level failures
        "txn_id":        None,
        "date":          None,
        "reg":           None,
        "inserted_at":   datetime.utcnow().isoformat(),
    }]

    errors = BQ_CLIENT.insert_rows_json(ERROR_TABLE, row)
    if errors:
        print(f"[ErrorLogger] Failed to write error log: {errors}")


def log_validation_errors(context: dict, failed_rows: list[dict], table_name: str):
    """
    Use this when you catch row-level validation errors in Python tasks.

    Args:
        context     : Airflow task context
        failed_rows : List of dicts with keys: record, error, error_type
        table_name  : Target BQ table where insert was attempted
    """
    import json

    if not failed_rows:
        return

    error_log_rows = []
    for item in failed_rows:
        record = item.get("record", {})
        error_log_rows.append({
            "dag_id":        context["dag"].dag_id,
            "task_id":       context["task_instance"].task_id,
            "dag_run_id":    context.get("run_id", "unknown"),
            "run_timestamp": datetime.utcnow().isoformat(),
            "error_type":    item.get("error_type", "ValidationError"),
            "error_message": item.get("error", ""),
            "traceback":     None,
            "table_name":    table_name,
            "record_json":   json.dumps(record),
            # Extract key fields — update these to match your schema
            "txn_id":        str(record.get("txn", "")),
            "date":          str(record.get("date", "")),
            "reg":           str(record.get("reg", "")),
            "inserted_at":   datetime.utcnow().isoformat(),
        })

    errors = BQ_CLIENT.insert_rows_json(ERROR_TABLE, error_log_rows)
    if errors:
        print(f"[ErrorLogger] Failed to write validation errors: {errors}")


def _extract_table_name(ti) -> str:
    """Pull destination table from BigQueryInsertJobOperator config."""
    try:
        config = ti.task.configuration
        dest   = config.get("query", {}).get("destinationTable", {})
        parts  = [
            dest.get("projectId", ""),
            dest.get("datasetId", ""),
            dest.get("tableId",   ""),
        ]
        return ".".join(p for p in parts if p) or "unknown"
    except Exception:
        return "unknown"
