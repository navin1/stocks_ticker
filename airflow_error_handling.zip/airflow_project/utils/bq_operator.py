# utils/bq_operator.py
#
# Drop-in wrapper around BigQueryInsertJobOperator.
# - Loads SQL from .sql file automatically
# - Auto-attaches on_failure_callback for error logging
# - Reused across ALL DAGs and modules

from pathlib import Path
from airflow.providers.google.cloud.operators.bigquery import BigQueryInsertJobOperator
from utils.error_logger import on_task_failure
from utils.sql_loader import load_sql


def create_bq_task(
    task_id:    str,
    sql_path:   str | Path,
    sql_params: dict = None,
    gcp_conn_id: str = "google_cloud_default",
    retries:    int  = 2,
    **kwargs,
) -> BigQueryInsertJobOperator:
    """
    Factory that returns a BigQueryInsertJobOperator with:
      - SQL loaded from file
      - on_failure_callback auto-attached for error logging

    Args:
        task_id     : Airflow task id (must be unique within DAG)
        sql_path    : Absolute path to .sql file
        sql_params  : Optional dict for runtime SQL params (dag_id, run_id etc.)
        gcp_conn_id : Airflow GCP connection id (default: google_cloud_default)
        retries     : Number of Airflow retries (default: 2)
        **kwargs    : Any other BigQueryInsertJobOperator args (e.g. dag=dag)

    Returns:
        Configured BigQueryInsertJobOperator instance

    Example:
        create_bq_task(
            task_id    = "validate_sales",
            sql_path   = SQL_BASE / "validate_sales.sql",
            sql_params = {"dag_id": "dag_finance_1", "run_id": "{{ run_id }}"},
        )
    """
    sql = load_sql(sql_path, sql_params)

    return BigQueryInsertJobOperator(
        task_id=task_id,
        configuration={
            "query": {
                "query":        sql,
                "useLegacySql": False,
            }
        },
        gcp_conn_id=gcp_conn_id,
        on_failure_callback=on_task_failure,   # ✅ always attached
        retries=retries,
        **kwargs,
    )
