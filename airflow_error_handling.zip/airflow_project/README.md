# Airflow DAG Error Handling — Centralized BQ Error Logging

## Project Structure

```
airflow_project/
  utils/
    error_logger.py     ← Centralized BQ error logger (define once)
    sql_loader.py       ← Loads .sql files + injects runtime params
    bq_operator.py      ← create_bq_task() factory (define once)
  modules/
    finance/
      dags/
        dag_finance_1.py    ← Sales & Returns pipeline
        dag_finance_2.py    ← Invoices pipeline
      sql/
        dag_finance_1/
          validate_sales.sql
          insert_sales.sql
          validate_returns.sql
          insert_returns.sql
        dag_finance_2/
          validate_invoices.sql
          insert_invoices.sql
    operations/
      dags/
        dag_ops_1.py        ← Transactions pipeline
      sql/
        dag_ops_1/
          validate_transactions.sql
          insert_transactions.sql
  sql/
    setup/
      create_error_log_table.sql   ← Run this first!
```

---

## Setup Steps

### 1. Create the Error Log Table
Run this in BigQuery **once** before deploying any DAGs:
```
sql/setup/create_error_log_table.sql
```
Update `your_project` and `your_dataset` to your actual values.

### 2. Update Project/Dataset References
Search and replace `your_project.your_dataset` across all `.sql` files
with your actual GCP project and dataset.

### 3. Deploy to Airflow
Copy the `modules/` and `utils/` folders to your Airflow DAGs folder.
Ensure `utils/` is importable from each DAG (the `sys.path.insert` in each
DAG handles this automatically).

### 4. Verify GCP Connection
Ensure the Airflow connection `google_cloud_default` is configured with
the correct service account credentials.

---

## How It Works

### Error Flow for Job-Level Failures (SQL errors, quota, infra)
```
BigQueryInsertJobOperator fails
    → on_failure_callback fires automatically
    → on_task_failure() in error_logger.py
    → Inserts row into dag_error_log with traceback
```

### Error Flow for Row-Level Bad Records
```
validate_xxx.sql runs first
    → Finds bad records via WHERE clause
    → Inserts them directly into dag_error_log via TO_JSON_STRING()
insert_xxx.sql runs after
    → Only inserts clean records (inverse WHERE clause)
```

### Adding a New DAG
1. Create `modules/<module>/dags/dag_new.py`
2. Create `modules/<module>/sql/dag_new/validate_xxx.sql`
3. Create `modules/<module>/sql/dag_new/insert_xxx.sql`
4. Use `create_bq_task()` — error logging is automatic

---

## Querying Error Logs

```sql
-- All failures today
SELECT dag_id, task_id, table_name, error_type, error_message, txn_id, date, reg
FROM `your_project.your_dataset.dag_error_log`
WHERE DATE(inserted_at) = CURRENT_DATE()
ORDER BY inserted_at DESC;

-- Failure count per DAG
SELECT dag_id, task_id, error_type, COUNT(*) AS failure_count
FROM `your_project.your_dataset.dag_error_log`
GROUP BY 1, 2, 3
ORDER BY failure_count DESC;

-- Inspect full failing record
SELECT record_json, JSON_VALUE(record_json, '$.txn') AS txn
FROM `your_project.your_dataset.dag_error_log`
WHERE dag_id = 'dag_finance_1'
  AND DATE(inserted_at) = CURRENT_DATE();
```

---

## Key Design Decisions

| Concern                        | Solution                                              |
|-------------------------------|-------------------------------------------------------|
| N DAGs, no duplication        | `create_bq_task()` factory — one line per task        |
| SQL in files, not in DAG code | `sql_loader.py` reads from path relative to DAG file  |
| Runtime params in SQL         | `sql_params` dict → `str.format()` at load time       |
| Job-level error logging       | `on_failure_callback` auto-attached in factory        |
| Row-level bad record capture  | `TO_JSON_STRING(t)` in validate SQL → error log table |
| Key fields queryable          | Extracted as flat columns alongside `record_json`     |
| Partition + cluster           | Error log table partitioned by date, clustered by dag |
