-- modules/operations/sql/dag_ops_1/insert_transactions.sql
--
-- Inserts only clean transaction records to target table.

INSERT INTO `your_project.your_dataset.transactions`

SELECT *
FROM `your_project.your_dataset.transactions_stage`

WHERE
  txn    IS NOT NULL
  AND date   IS NOT NULL
  AND amount IS NOT NULL
  AND reg    IS NOT NULL
  AND type   IS NOT NULL;
