# modules/operations/dags/dag_ops_1.py
#
# Operations DAG 1 — Transactions pipeline
# Tasks: validate → insert
# Error logging: auto-attached via create_bq_task factory

from airflow import DAG
from airflow.utils.dates import days_ago
from pathlib import Path
import sys

# ── Make utils importable ───────────────────────────────────────────
sys.path.insert(0, str(Path(__file__).parents[3]))  # project root
from utils.bq_operator import create_bq_task

# ── SQL base path — relative to THIS dag file ───────────────────────
SQL_BASE = Path(__file__).parents[1] / "sql" / "dag_ops_1"

DAG_ID = "dag_ops_1"

# ── DAG definition ──────────────────────────────────────────────────
with DAG(
    dag_id=DAG_ID,
    description="Operations pipeline — Transactions with error logging",
    start_date=days_ago(1),
    schedule_interval="@daily",
    catchup=False,
    tags=["operations"],
) as dag:

    # ── Transaction tasks ────────────────────────────────────────────
    validate_transactions = create_bq_task(
        task_id    = "validate_transactions",
        sql_path   = SQL_BASE / "validate_transactions.sql",
        sql_params = {"dag_id": DAG_ID, "run_id": "{{ run_id }}"},
    )

    insert_transactions = create_bq_task(
        task_id  = "insert_transactions",
        sql_path = SQL_BASE / "insert_transactions.sql",
    )

    # ── Task dependencies ────────────────────────────────────────────
    validate_transactions >> insert_transactions
