-- modules/finance/sql/dag_finance_1/insert_sales.sql
--
-- Inserts only clean (validated) records from staging to target table.
-- Runs AFTER validate_sales.sql has quarantined bad records.

INSERT INTO `your_project.your_dataset.sales`

SELECT *
FROM `your_project.your_dataset.sales_stage`

WHERE
  txn    IS NOT NULL
  AND date   IS NOT NULL
  AND amount >= 0
  AND reg    IS NOT NULL;
