-- modules/finance/sql/dag_finance_1/validate_sales.sql
--
-- Quarantines bad records from staging into dag_error_log BEFORE insert.
-- Runtime params injected by sql_loader: {dag_id}, {run_id}

INSERT INTO `your_project.your_dataset.dag_error_log`
  (dag_id, task_id, table_name, dag_run_id, run_timestamp,
   error_type, record_json, txn_id, date, reg, inserted_at)

SELECT
  '{dag_id}'                      AS dag_id,
  'validate_sales'                AS task_id,
  'your_dataset.sales'            AS table_name,
  '{run_id}'                      AS dag_run_id,
  CURRENT_TIMESTAMP()             AS run_timestamp,
  'ValidationError'               AS error_type,
  TO_JSON_STRING(t)               AS record_json,   -- full failing row as JSON
  CAST(t.txn    AS STRING)        AS txn_id,
  CAST(t.date   AS STRING)        AS date,
  t.reg                           AS reg,
  CURRENT_TIMESTAMP()             AS inserted_at

FROM `your_project.your_dataset.sales_stage` t

WHERE
  t.txn    IS NULL       -- missing transaction id
  OR t.date IS NULL      -- missing date
  OR t.amount < 0        -- invalid amount
  OR t.reg  IS NULL;     -- missing region
