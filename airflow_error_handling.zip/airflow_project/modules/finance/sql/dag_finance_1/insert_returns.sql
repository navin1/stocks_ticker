-- modules/finance/sql/dag_finance_1/insert_returns.sql
--
-- Inserts only clean records from returns staging to target table.

INSERT INTO `your_project.your_dataset.returns`

SELECT *
FROM `your_project.your_dataset.returns_stage`

WHERE
  txn    IS NOT NULL
  AND date   IS NOT NULL
  AND amount IS NOT NULL
  AND reg    IS NOT NULL;
