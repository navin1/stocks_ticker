-- modules/finance/sql/dag_finance_2/insert_invoices.sql
--
-- Inserts only clean invoice records to target table.

INSERT INTO `your_project.your_dataset.invoices`

SELECT *
FROM `your_project.your_dataset.invoices_stage`

WHERE
  invoice_id   IS NOT NULL
  AND invoice_date IS NOT NULL
  AND amount   > 0
  AND region   IS NOT NULL;
