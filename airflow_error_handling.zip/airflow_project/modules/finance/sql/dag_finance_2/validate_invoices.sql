-- modules/finance/sql/dag_finance_2/validate_invoices.sql
--
-- Quarantines bad invoice records into dag_error_log.
-- Runtime params: {dag_id}, {run_id}

INSERT INTO `your_project.your_dataset.dag_error_log`
  (dag_id, task_id, table_name, dag_run_id, run_timestamp,
   error_type, record_json, txn_id, date, reg, inserted_at)

SELECT
  '{dag_id}'                      AS dag_id,
  'validate_invoices'             AS task_id,
  'your_dataset.invoices'         AS table_name,
  '{run_id}'                      AS dag_run_id,
  CURRENT_TIMESTAMP()             AS run_timestamp,
  'ValidationError'               AS error_type,
  TO_JSON_STRING(t)               AS record_json,
  CAST(t.invoice_id AS STRING)    AS txn_id,
  CAST(t.invoice_date AS STRING)  AS date,
  t.region                        AS reg,
  CURRENT_TIMESTAMP()             AS inserted_at

FROM `your_project.your_dataset.invoices_stage` t

WHERE
  t.invoice_id   IS NULL
  OR t.invoice_date IS NULL
  OR t.amount    <= 0
  OR t.region    IS NULL;
