# modules/finance/dags/dag_finance_2.py
#
# Finance DAG 2 — Invoices pipeline
# Tasks: validate → insert
# Error logging: auto-attached via create_bq_task factory

from airflow import DAG
from airflow.utils.dates import days_ago
from pathlib import Path
import sys

# ── Make utils importable ───────────────────────────────────────────
sys.path.insert(0, str(Path(__file__).parents[3]))  # project root
from utils.bq_operator import create_bq_task

# ── SQL base path — relative to THIS dag file ───────────────────────
SQL_BASE = Path(__file__).parents[1] / "sql" / "dag_finance_2"

DAG_ID = "dag_finance_2"

# ── DAG definition ──────────────────────────────────────────────────
with DAG(
    dag_id=DAG_ID,
    description="Finance pipeline — Invoices with error logging",
    start_date=days_ago(1),
    schedule_interval="@daily",
    catchup=False,
    tags=["finance"],
) as dag:

    # ── Invoice tasks ────────────────────────────────────────────────
    validate_invoices = create_bq_task(
        task_id    = "validate_invoices",
        sql_path   = SQL_BASE / "validate_invoices.sql",
        sql_params = {"dag_id": DAG_ID, "run_id": "{{ run_id }}"},
    )

    insert_invoices = create_bq_task(
        task_id  = "insert_invoices",
        sql_path = SQL_BASE / "insert_invoices.sql",
    )

    # ── Task dependencies ────────────────────────────────────────────
    validate_invoices >> insert_invoices
