# modules/finance/dags/dag_finance_1.py
#
# Finance DAG 1 — Sales & Returns pipeline
# Tasks: validate → insert for each entity
# Error logging: auto-attached via create_bq_task factory

from airflow import DAG
from airflow.utils.dates import days_ago
from pathlib import Path
import sys

# ── Make utils importable ───────────────────────────────────────────
sys.path.insert(0, str(Path(__file__).parents[3]))  # project root
from utils.bq_operator import create_bq_task

# ── SQL base path — relative to THIS dag file ───────────────────────
SQL_BASE = Path(__file__).parents[1] / "sql" / "dag_finance_1"

DAG_ID = "dag_finance_1"

# ── DAG definition ──────────────────────────────────────────────────
with DAG(
    dag_id=DAG_ID,
    description="Finance pipeline — Sales and Returns with error logging",
    start_date=days_ago(1),
    schedule_interval="@daily",
    catchup=False,
    tags=["finance"],
) as dag:

    # ── Sales tasks ─────────────────────────────────────────────────
    validate_sales = create_bq_task(
        task_id    = "validate_sales",
        sql_path   = SQL_BASE / "validate_sales.sql",
        sql_params = {"dag_id": DAG_ID, "run_id": "{{ run_id }}"},
    )

    insert_sales = create_bq_task(
        task_id  = "insert_sales",
        sql_path = SQL_BASE / "insert_sales.sql",
    )

    # ── Returns tasks ────────────────────────────────────────────────
    validate_returns = create_bq_task(
        task_id    = "validate_returns",
        sql_path   = SQL_BASE / "validate_returns.sql",
        sql_params = {"dag_id": DAG_ID, "run_id": "{{ run_id }}"},
    )

    insert_returns = create_bq_task(
        task_id  = "insert_returns",
        sql_path = SQL_BASE / "insert_returns.sql",
    )

    # ── Task dependencies ────────────────────────────────────────────
    validate_sales >> insert_sales >> validate_returns >> insert_returns
