-- sql/setup/create_error_log_table.sql
--
-- Run this once to create the centralized error log table.
-- Update your_project and your_dataset before running.

CREATE TABLE IF NOT EXISTS `your_project.your_dataset.dag_error_log`
(
  dag_id        STRING    OPTIONS (description = 'Airflow DAG id'),
  task_id       STRING    OPTIONS (description = 'Airflow Task id'),
  table_name    STRING    OPTIONS (description = 'Target BQ table where insert was attempted'),
  dag_run_id    STRING    OPTIONS (description = 'Airflow DAG run id'),
  run_timestamp TIMESTAMP OPTIONS (description = 'DAG execution timestamp'),
  error_type    STRING    OPTIONS (description = 'Python exception class or BQInsertError'),
  error_message STRING    OPTIONS (description = 'Short error message'),
  traceback     STRING    OPTIONS (description = 'Full Python traceback for job-level errors'),
  record_json   JSON      OPTIONS (description = 'Full failing record as JSON (row-level errors)'),

  -- Key fields extracted from record_json for easy querying
  -- Update these columns to match your actual record schema
  txn_id        STRING    OPTIONS (description = 'Transaction id extracted from record'),
  date          STRING    OPTIONS (description = 'Date extracted from record'),
  reg           STRING    OPTIONS (description = 'Region extracted from record'),

  inserted_at   TIMESTAMP OPTIONS (description = 'When this error row was inserted')
)
PARTITION BY DATE(inserted_at)
CLUSTER BY dag_id, task_id
OPTIONS (
  description = 'Centralized DAG error log — all task failures across all DAGs'
);
